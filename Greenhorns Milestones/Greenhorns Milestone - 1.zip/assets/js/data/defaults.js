
export const HEROIC_LEVEL = {
  name: 'Greenhorn',
  attributePoints: 42,
  traitPoints: 0,
  skillPoints: 62,
  maxAttribute: 'd12',
  maxSkill: 'd12'
};

export const ATTRIBUTE_LIST = [
  'Agility',
  'Strength',
  'Vitality',
  'Alertness',
  'Intelligence',
  'Willpower'
];

export const DIE_COSTS = {
  'none': 0,
  'd2': 2,
  'd4': 4,
  'd6': 6,
  'd8': 8,
  'd10': 10,
  'd12': 12
};

export const ATTRIBUTE_OPTIONS = ['d4', 'd6', 'd8', 'd10', 'd12'];
export const GENERAL_SKILL_OPTIONS = ['none', 'd2', 'd4', 'd6'];
export const SPECIALTY_OPTIONS = ['none', 'd8', 'd10', 'd12'];
export const TRAIT_OPTIONS = ['none', 'd2', 'd4'];

export function createDefaultCharacter() {
  return {
    basics: {
      name: '',
      quote: '',
      concept: '',
      role: '',
      homeworld: '',
      background: ''
    },
    attributes: {
      Agility: 'd4',
      Strength: 'd4',
      Vitality: 'd4',
      Alertness: 'd4',
      Intelligence: 'd4',
      Willpower: 'd4'
    },
    traits: {
      assets: [createEmptyTrait('asset')],
      complications: [createEmptyTrait('complication')]
    },
    skills: {},
    details: {
      gear: '',
      notes: '',
      portraitUrl: ''
    },
    meta: {
      heroicLevel: HEROIC_LEVEL.name,
      lastUpdated: null
    }
  };
}

export function createEmptyTrait(type = 'asset') {
  return {
    id: crypto.randomUUID(),
    category: type,
    name: '',
    rating: 'none',
    source: 'curated',
    notes: ''
  };
}

export function createEmptySpecialty() {
  return {
    id: crypto.randomUUID(),
    name: '',
    rating: 'none'
  };
}
