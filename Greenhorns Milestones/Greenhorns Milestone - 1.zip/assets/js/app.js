
import { HEROIC_LEVEL } from './data/defaults.js';
import { loadState, saveState, clearState, exportState } from './storage.js';
import { hydrateCharacter } from './state.js';
import { remainingBudgets, validateCharacter, lifePoints, initiative } from './rules.js';
import { renderBasicsStep } from './steps/step_basics.js';
import { renderAttributesStep } from './steps/step_attributes.js';
import { renderTraitsStep } from './steps/step_traits.js';
import { renderSkillsStep } from './steps/step_skills.js';
import { renderDetailsStep } from './steps/step_details.js';
import { renderSheetStep } from './steps/step_sheet.js';
import { setMessage, el } from './ui.js';

const steps = [
  { id: 'basics', label: '1. Basics', render: renderBasicsStep },
  { id: 'attributes', label: '2. Attributes', render: renderAttributesStep },
  { id: 'traits', label: '3. Traits', render: renderTraitsStep },
  { id: 'skills', label: '4. Skills', render: renderSkillsStep },
  { id: 'details', label: '5. Details', render: renderDetailsStep },
  { id: 'sheet', label: '6. Character Sheet', render: renderSheetStep }
];

let state = {
  stepIndex: 0,
  character: hydrateCharacter(loadState())
};

const els = {
  stepNav: document.getElementById('stepNav'),
  stepContent: document.getElementById('stepContent'),
  attributePointsRemaining: document.getElementById('attributePointsRemaining'),
  traitPointsRemaining: document.getElementById('traitPointsRemaining'),
  skillPointsRemaining: document.getElementById('skillPointsRemaining'),
  lifePointsValue: document.getElementById('lifePointsValue'),
  initiativeValue: document.getElementById('initiativeValue'),
  backBtn: document.getElementById('backBtn'),
  nextBtn: document.getElementById('nextBtn'),
  saveBtn: document.getElementById('saveBtn'),
  exportBtn: document.getElementById('exportBtn'),
  importInput: document.getElementById('importInput'),
  resetBtn: document.getElementById('resetBtn'),
  printBtn: document.getElementById('printBtn'),
  messageBar: document.getElementById('messageBar')
};

function compute() {
  const validation = validateCharacter(state.character);
  return {
    ...validation,
    budgets: remainingBudgets(state.character),
    lifePoints: lifePoints(state.character),
    initiative: initiative(state.character)
  };
}

function updateStatus(computed) {
  els.attributePointsRemaining.textContent = computed.budgets.attributes;
  els.traitPointsRemaining.textContent = computed.budgets.traits;
  els.skillPointsRemaining.textContent = computed.budgets.skills;
  els.lifePointsValue.textContent = computed.lifePoints;
  els.initiativeValue.textContent = computed.initiative;

  for (const [key, value, node] of [
    ['attributes', computed.budgets.attributes, els.attributePointsRemaining],
    ['traits', computed.budgets.traits, els.traitPointsRemaining],
    ['skills', computed.budgets.skills, els.skillPointsRemaining]
  ]) {
    node.parentElement.style.borderColor = value < 0 || (key === 'attributes' && value !== 0) ? 'var(--danger)' : 'var(--line)';
  }
}

function renderNav(computed) {
  els.stepNav.innerHTML = '';
  steps.forEach((step, index) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.textContent = step.label;
    if (index === state.stepIndex) button.classList.add('active');
    if (index === steps.length - 1 && !computed.valid) button.classList.add('invalid');
    button.addEventListener('click', () => {
      state.stepIndex = index;
      render();
    });
    els.stepNav.append(button);
  });
}

function mutateCharacter(mutator) {
  const draft = structuredClone(state.character);
  mutator(draft);
  draft.meta.lastUpdated = new Date().toISOString();
  state.character = draft;
  saveState(state.character);
  render();
}

function renderStep(computed) {
  els.stepContent.innerHTML = '';
  const current = steps[state.stepIndex];
  const stepState = { character: state.character, computed, heroicLevel: HEROIC_LEVEL };
  const node = current.render(stepState, mutateCharacter);
  els.stepContent.append(node);
}

function render() {
  const computed = compute();
  updateStatus(computed);
  renderNav(computed);
  renderStep(computed);

  els.backBtn.disabled = state.stepIndex === 0;
  els.nextBtn.disabled = state.stepIndex === steps.length - 1;
  els.nextBtn.textContent = state.stepIndex === steps.length - 2 ? 'Finish' : 'Next';

  if (state.stepIndex === steps.length - 1) {
    setMessage(els.messageBar, computed.valid ? 'Build checks out. Print it or export it.' : 'Build still has issues. See the character sheet step for the exact list.', computed.valid ? 'ok' : 'warn');
  } else {
    setMessage(els.messageBar, '');
  }
}

els.backBtn.addEventListener('click', () => {
  if (state.stepIndex > 0) {
    state.stepIndex -= 1;
    render();
  }
});

els.nextBtn.addEventListener('click', () => {
  if (state.stepIndex < steps.length - 1) {
    state.stepIndex += 1;
    render();
  }
});

els.saveBtn.addEventListener('click', () => {
  saveState(state.character);
  setMessage(els.messageBar, 'Saved locally in this browser.', 'ok');
});

els.exportBtn.addEventListener('click', () => exportState(state.character));

els.importInput.addEventListener('change', async (event) => {
  const file = event.target.files?.[0];
  if (!file) return;
  const raw = await file.text();
  const parsed = JSON.parse(raw);
  state.character = hydrateCharacter(parsed);
  state.stepIndex = 0;
  saveState(state.character);
  render();
});

els.resetBtn.addEventListener('click', () => {
  if (!confirm('Reset the builder and wipe the local saved character?')) return;
  clearState();
  state.character = hydrateCharacter(null);
  state.stepIndex = 0;
  render();
});

els.printBtn.addEventListener('click', () => {
  if (state.stepIndex !== steps.length - 1) state.stepIndex = steps.length - 1;
  render();
  window.print();
});

render();
