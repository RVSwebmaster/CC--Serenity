
import { el, field, sectionHeader } from '../ui.js';

export function renderDetailsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 5: Details', 'Keep this light. Gear, notes, maybe a portrait link if you have one.'));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const portrait = document.createElement('input');
  portrait.value = state.character.details.portraitUrl || '';
  portrait.placeholder = 'https://...';
  portrait.addEventListener('input', (event) => onChange((draft) => { draft.details.portraitUrl = event.target.value; }));
  left.append(field('Portrait URL (optional)', portrait, 'No upload system in the MVP. A simple image link works.'));

  const gear = document.createElement('textarea');
  gear.value = state.character.details.gear || '';
  gear.addEventListener('input', (event) => onChange((draft) => { draft.details.gear = event.target.value; }));
  left.append(field('Gear', gear, 'Weapons, tools, med kit, coat, lucky trinket, whatever matters.'));

  const notes = document.createElement('textarea');
  notes.value = state.character.details.notes || '';
  notes.addEventListener('input', (event) => onChange((draft) => { draft.details.notes = event.target.value; }));
  right.append(field('Extra Notes', notes, 'Hooks for the GM, personal reminders, ship duty, debts, enemies.'));

  grid.append(left, right);
  root.append(grid);
  return root;
}
