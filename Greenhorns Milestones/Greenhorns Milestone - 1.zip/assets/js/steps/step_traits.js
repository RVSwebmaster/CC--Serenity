
import { createEmptyTrait, TRAIT_OPTIONS } from '../data/defaults.js';
import { CURATED_ASSETS, CURATED_COMPLICATIONS } from '../data/traits.js';
import { el, sectionHeader } from '../ui.js';

function buildTraitSection(title, list, curated, onChange, category) {
  const wrap = el('div', { cls: 'field-card' });
  wrap.append(el('h3', { text: title }));
  wrap.append(el('div', { cls: 'trait-row header' }, [
    el('div', { text: 'Trait' }),
    el('div', { text: 'Mode' }),
    el('div', { text: 'Die' }),
    el('div', { text: 'Points' }),
    el('div', { text: 'Notes' }),
    el('div', { text: '' })
  ]));

  list.forEach((trait) => {
    const traitMeta = curated.find((item) => item.name === trait.name);
    const nameWrap = el('div');

    const sourceSelect = document.createElement('select');
    ['curated', 'manual'].forEach((mode) => {
      const opt = document.createElement('option');
      opt.value = mode;
      opt.textContent = mode === 'curated' ? 'Pick list' : 'Manual';
      if ((trait.source || 'curated') === mode) opt.selected = true;
      sourceSelect.append(opt);
    });
    sourceSelect.addEventListener('change', (event) => onChange((draft) => {
      const target = draft.traits[category === 'asset' ? 'assets' : 'complications'].find((item) => item.id === trait.id);
      target.source = event.target.value;
      if (event.target.value === 'manual' && !target.name) target.name = '';
    }));

    let nameInput;
    if ((trait.source || 'curated') === 'manual') {
      nameInput = document.createElement('input');
      nameInput.value = trait.name;
      nameInput.placeholder = 'Enter trait name';
    } else {
      nameInput = document.createElement('select');
      const blank = document.createElement('option');
      blank.value = '';
      blank.textContent = 'Choose a trait';
      nameInput.append(blank);
      curated.forEach((item) => {
        const opt = document.createElement('option');
        opt.value = item.name;
        opt.textContent = item.name;
        if (trait.name === item.name) opt.selected = true;
        nameInput.append(opt);
      });
    }
    nameInput.addEventListener('input', (event) => onChange((draft) => {
      const target = draft.traits[category === 'asset' ? 'assets' : 'complications'].find((item) => item.id === trait.id);
      target.name = event.target.value;
      const match = curated.find((item) => item.name === target.name);
      if (match && !match.allowedRatings.includes(target.rating)) {
        target.rating = match.allowedRatings[0];
      }
    }));
    nameWrap.append(nameInput);
    if (traitMeta) nameWrap.append(el('small', { cls: 'help', text: traitMeta.summary }));

    const ratingSelect = document.createElement('select');
    const allowedRatings = traitMeta?.allowedRatings || TRAIT_OPTIONS.filter((item) => item !== 'none');
    ['none', ...allowedRatings].forEach((rating) => {
      const opt = document.createElement('option');
      opt.value = rating;
      opt.textContent = rating === 'none' ? '—' : rating;
      if (trait.rating === rating) opt.selected = true;
      ratingSelect.append(opt);
    });
    ratingSelect.addEventListener('change', (event) => onChange((draft) => {
      const target = draft.traits[category === 'asset' ? 'assets' : 'complications'].find((item) => item.id === trait.id);
      target.rating = event.target.value;
    }));

    const notes = document.createElement('input');
    notes.value = trait.notes || '';
    notes.placeholder = 'Focus, edge, trigger, or reminder';
    notes.addEventListener('input', (event) => onChange((draft) => {
      const target = draft.traits[category === 'asset' ? 'assets' : 'complications'].find((item) => item.id === trait.id);
      target.notes = event.target.value;
    }));

    const removeButton = document.createElement('button');
    removeButton.type = 'button';
    removeButton.textContent = 'Remove';
    removeButton.addEventListener('click', () => onChange((draft) => {
      const key = category === 'asset' ? 'assets' : 'complications';
      draft.traits[key] = draft.traits[key].filter((item) => item.id !== trait.id);
      if (draft.traits[key].length === 0) draft.traits[key].push(createEmptyTrait(category));
    }));

    wrap.append(el('div', { cls: 'trait-row' }, [
      nameWrap,
      sourceSelect,
      ratingSelect,
      el('div', { html: `<span class="points-badge">${trait.rating === 'none' ? 0 : trait.rating.replace('d', '')}</span>` }),
      notes,
      removeButton
    ]));
  });

  const addButton = document.createElement('button');
  addButton.type = 'button';
  addButton.textContent = `Add ${title.slice(0, -1)}`;
  addButton.addEventListener('click', () => onChange((draft) => {
    const key = category === 'asset' ? 'assets' : 'complications';
    draft.traits[key].push(createEmptyTrait(category));
  }));
  wrap.append(el('div', { cls: 'section-actions' }, [addButton]));
  return wrap;
}

export function renderTraitsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 3: Traits', 'Greenhorns start with 0 Trait Points. Complications fund Assets.'));

  root.append(el('div', { cls: 'summary-card' }, [
    el('p', { text: 'Quick rule: choose at least one Asset and one Complication. Keep the final Trait Point remainder at 0 or higher. d2 is the quick “minor” stand-in, d4 the rough “major” stand-in.' })
  ]));

  const grid = el('div', { cls: 'grid-2' }, [
    buildTraitSection('Assets', state.character.traits.assets, CURATED_ASSETS, onChange, 'asset'),
    buildTraitSection('Complications', state.character.traits.complications, CURATED_COMPLICATIONS, onChange, 'complication')
  ]);
  root.append(grid);
  return root;
}
