
import { GENERAL_SKILL_OPTIONS, SPECIALTY_OPTIONS, createEmptySpecialty } from '../data/defaults.js';
import { SKILLS } from '../data/skills.js';
import { dieCost } from '../rules.js';
import { el, sectionHeader } from '../ui.js';

function buildOptions(select, options, current) {
  options.forEach((option) => {
    const opt = document.createElement('option');
    opt.value = option;
    opt.textContent = option === 'none' ? '—' : option;
    if (current === option) opt.selected = true;
    select.append(opt);
  });
}

export function renderSkillsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 4: Skills', 'Spend 62 Skill Points. General Skills top out at d6. Specialties start at d8 and need the parent skill at d6.'));

  const wrap = el('div', { cls: 'table-wrap' });
  wrap.append(el('div', { cls: 'skill-row header' }, [
    el('div', { text: 'Skill' }),
    el('div', { text: 'General' }),
    el('div', { text: 'Cost' }),
    el('div', { text: 'Specialties' }),
    el('div', { text: 'SP' }),
    el('div', { text: '' })
  ]));

  SKILLS.forEach((skillMeta) => {
    const skill = state.character.skills[skillMeta.name];
    const generalSelect = document.createElement('select');
    buildOptions(generalSelect, GENERAL_SKILL_OPTIONS, skill.generalRating);
    generalSelect.addEventListener('change', (event) => onChange((draft) => {
      draft.skills[skillMeta.name].generalRating = event.target.value;
      if (event.target.value !== 'd6') {
        draft.skills[skillMeta.name].specialties = draft.skills[skillMeta.name].specialties.map((specialty) => ({ ...specialty, rating: 'none' }));
      }
    }));

    const specialtyWrap = el('div');
    skill.specialties.forEach((specialty) => {
      const line = el('div', { cls: 'inline-fields' });
      const nameInput = document.createElement('input');
      nameInput.value = specialty.name;
      nameInput.placeholder = skillMeta.specialties[0] || 'Specialty name';
      nameInput.addEventListener('input', (event) => onChange((draft) => {
        const target = draft.skills[skillMeta.name].specialties.find((item) => item.id === specialty.id);
        target.name = event.target.value;
      }));

      const ratingSelect = document.createElement('select');
      buildOptions(ratingSelect, SPECIALTY_OPTIONS, specialty.rating);
      ratingSelect.disabled = skill.generalRating !== 'd6';
      ratingSelect.addEventListener('change', (event) => onChange((draft) => {
        const target = draft.skills[skillMeta.name].specialties.find((item) => item.id === specialty.id);
        target.rating = event.target.value;
      }));

      const removeButton = document.createElement('button');
      removeButton.type = 'button';
      removeButton.textContent = 'X';
      removeButton.addEventListener('click', () => onChange((draft) => {
        draft.skills[skillMeta.name].specialties = draft.skills[skillMeta.name].specialties.filter((item) => item.id !== specialty.id);
      }));

      line.append(nameInput, ratingSelect, removeButton);
      specialtyWrap.append(line);
    });

    const addSpecButton = document.createElement('button');
    addSpecButton.type = 'button';
    addSpecButton.textContent = 'Add Specialty';
    addSpecButton.disabled = skill.generalRating !== 'd6';
    addSpecButton.addEventListener('click', () => onChange((draft) => {
      draft.skills[skillMeta.name].specialties.push(createEmptySpecialty());
    }));
    specialtyWrap.append(el('div', { cls: 'section-actions' }, [addSpecButton]));

    const specialtyPoints = skill.specialties.reduce((sum, specialty) => sum + dieCost(specialty.rating), 0);

    wrap.append(el('div', { cls: 'skill-row' }, [
      el('div', { html: `<strong>${skillMeta.name}</strong><br><span class="muted">Examples: ${skillMeta.specialties.slice(0, 4).join(', ') || 'none listed'}</span>` }),
      generalSelect,
      el('div', { html: `<span class="points-badge">${dieCost(skill.generalRating)}</span>` }),
      specialtyWrap,
      el('div', { html: `<span class="points-badge">${specialtyPoints}</span>` }),
      el('div')
    ]));
  });

  root.append(wrap);
  return root;
}
