
import { ATTRIBUTE_LIST, ATTRIBUTE_OPTIONS } from '../data/defaults.js';
import { dieCost } from '../rules.js';
import { el, field, sectionHeader } from '../ui.js';

export function renderAttributesStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 2: Attributes', 'Spend exactly 42 points. Every Attribute must start between d4 and d12.'));

  const wrap = el('div', { cls: 'table-wrap' });
  wrap.append(el('div', { cls: 'attribute-row header' }, [
    el('div', { text: 'Attribute' }),
    el('div', { text: 'Die' }),
    el('div', { text: 'Cost' }),
    el('div', { text: 'What it covers' })
  ]));

  const helpText = {
    Agility: 'Speed, finesse, balance, and reflexes.',
    Strength: 'Lift, shove, grapple, and raw force.',
    Vitality: 'Toughness, resilience, and staying power.',
    Alertness: 'Notice the world before it notices you.',
    Intelligence: 'Reason, training, analysis, and know-how.',
    Willpower: 'Grit, nerve, and mental backbone.'
  };

  ATTRIBUTE_LIST.forEach((attribute) => {
    const select = document.createElement('select');
    ATTRIBUTE_OPTIONS.forEach((option) => {
      const opt = document.createElement('option');
      opt.value = option;
      opt.textContent = option;
      if (state.character.attributes[attribute] === option) opt.selected = true;
      select.append(opt);
    });

    select.addEventListener('change', (event) => onChange((draft) => {
      draft.attributes[attribute] = event.target.value;
    }));

    wrap.append(el('div', { cls: 'attribute-row' }, [
      el('div', { text: attribute }),
      select,
      el('div', { html: `<span class="points-badge">${dieCost(state.character.attributes[attribute])}</span>` }),
      el('div', { cls: 'muted', text: helpText[attribute] })
    ]));
  });

  const summary = el('div', { cls: 'grid-2' }, [
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Derived values' }),
      el('p', { html: `Life Points: <strong>${state.computed.lifePoints}</strong>` }),
      el('p', { html: `Initiative: <strong>${state.computed.initiative}</strong>` })
    ]),
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Spend reminder' }),
      el('p', { text: '42 points, no leftovers for the final build. Greenhorn max is d12.' })
    ])
  ]);

  root.append(wrap, summary);
  return root;
}
