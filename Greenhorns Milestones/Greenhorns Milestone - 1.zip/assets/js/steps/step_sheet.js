
import { ATTRIBUTE_LIST } from '../data/defaults.js';
import { el, sectionHeader } from '../ui.js';

function renderTraits(list) {
  const filtered = list.filter((item) => item.name && item.rating !== 'none');
  if (!filtered.length) return el('p', { cls: 'muted', text: 'None selected.' });
  return el('ul', { cls: 'summary-list' }, filtered.map((trait) =>
    el('li', { text: `${trait.name} ${trait.rating}${trait.notes ? ` — ${trait.notes}` : ''}` })
  ));
}

function renderSkills(character) {
  const table = el('table', { cls: 'skill-table' });
  const thead = el('thead');
  thead.append(el('tr', {}, [
    el('th', { text: 'Skill' }),
    el('th', { text: 'General' }),
    el('th', { text: 'Specialties' })
  ]));
  const tbody = el('tbody');

  Object.entries(character.skills).forEach(([skillName, skill]) => {
    const specs = (skill.specialties || []).filter((item) => item.rating !== 'none' && item.name.trim()).map((item) => `${item.name} ${item.rating}`).join(', ');
    if (skill.generalRating === 'none' && !specs) return;
    tbody.append(el('tr', {}, [
      el('td', { text: skillName }),
      el('td', { text: skill.generalRating === 'none' ? '—' : skill.generalRating }),
      el('td', { text: specs || '—' })
    ]));
  });

  table.append(thead, tbody);
  return table;
}

export function renderSheetStep(state) {
  const root = el('div');
  root.append(sectionHeader('Step 6: Character Sheet', 'This is the finished digital sheet. Print it, save it, or keep it open at the table.'));

  const validation = el('div', { cls: `validation-box${state.computed.valid ? ' ok' : ''}` });
  validation.append(el('h3', { text: state.computed.valid ? 'Build looks legal.' : 'Build needs fixing.' }));
  if (state.computed.valid) {
    validation.append(el('p', { text: 'Points, required Traits, and basic Greenhorn checks all pass.' }));
  } else {
    validation.append(el('ul', { cls: 'summary-list' }, state.computed.errors.map((error) => el('li', { text: error }))));
  }
  root.append(validation);

  const sheet = el('div', { cls: 'sheet-layout', attrs: { id: 'printableSheet' } });
  sheet.append(el('div', { cls: 'sheet-header' }, [
    el('div', {}, [
      el('h2', { text: state.character.basics.name || 'Unnamed Greenhorn' }),
      el('p', { text: state.character.basics.concept || 'No concept entered.' }),
      el('p', { cls: 'muted', text: state.character.basics.quote || '' })
    ]),
    el('div', { cls: 'sheet-block' }, [
      el('div', { html: `<strong>Role:</strong> ${state.character.basics.role || '—'}` }),
      el('div', { html: `<strong>Homeworld:</strong> ${state.character.basics.homeworld || '—'}` }),
      el('div', { html: `<strong>Heroic Level:</strong> ${state.character.meta.heroicLevel}` })
    ])
  ]));

  sheet.append(el('div', { cls: 'sheet-info-grid' }, [
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Life Points' }), el('strong', { text: String(state.computed.lifePoints) })]),
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Initiative' }), el('strong', { text: state.computed.initiative })]),
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Point Budgets' }), el('strong', { text: `A ${state.computed.budgets.attributes} | T ${state.computed.budgets.traits} | S ${state.computed.budgets.skills}` })])
  ]));

  sheet.append(el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Attributes' }),
    el('div', { cls: 'sheet-attr-grid' }, ATTRIBUTE_LIST.map((attribute) =>
      el('div', { cls: 'sheet-stat' }, [el('span', { text: attribute }), el('strong', { text: state.character.attributes[attribute] })])
    ))
  ]));

  sheet.append(el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Assets' }), renderTraits(state.character.traits.assets)]));
  sheet.append(el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Complications' }), renderTraits(state.character.traits.complications)]));
  sheet.append(el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Skills' }), renderSkills(state.character)]));
  sheet.append(el('div', { cls: 'sheet-info-grid' }, [
    el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Background' }), el('p', { text: state.character.basics.background || '—' })]),
    el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Gear' }), el('p', { text: state.character.details.gear || '—' })]),
    el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Notes' }), el('p', { text: state.character.details.notes || '—' })])
  ]));

  root.append(sheet);
  return root;
}
