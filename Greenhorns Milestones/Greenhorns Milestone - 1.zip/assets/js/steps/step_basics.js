
import { el, field, sectionHeader } from '../ui.js';

export function renderBasicsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 1: Basics', 'Who is this poor soul, and what do they do aboard ship.'));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const basics = [
    ['Name', 'name'],
    ['Quote', 'quote'],
    ['Concept', 'concept'],
    ['Role on the Crew', 'role'],
    ['Homeworld', 'homeworld']
  ];

  basics.forEach(([labelText, key]) => {
    const input = document.createElement('input');
    input.value = state.character.basics[key] || '';
    input.addEventListener('input', (event) => onChange((draft) => { draft.basics[key] = event.target.value; }));
    left.append(field(labelText, input));
  });

  const background = document.createElement('textarea');
  background.value = state.character.basics.background || '';
  background.addEventListener('input', (event) => onChange((draft) => { draft.basics.background = event.target.value; }));
  right.append(field('Background / Notes', background, 'Keep it short. Enough to know what sort of trouble they carry around.'));

  const tips = el('div', { cls: 'summary-card' }, [
    el('h3', { text: 'Quick prompts' }),
    el('ul', { cls: 'summary-list', html: `
      <li>What job do they handle aboard ship?</li>
      <li>Why are they with this crew instead of somewhere safer?</li>
      <li>What do they want badly enough to risk getting shot?</li>
      <li>What kind of folk do they trust, and why is that probably a mistake?</li>
    ` })
  ]);
  right.append(tips);

  grid.append(left, right);
  root.append(grid);
  return root;
}
