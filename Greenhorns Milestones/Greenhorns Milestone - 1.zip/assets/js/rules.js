
import { ATTRIBUTE_LIST, DIE_COSTS, HEROIC_LEVEL } from './data/defaults.js';

export function dieCost(die) {
  return DIE_COSTS[die] ?? 0;
}

export function calculateAttributePoints(character) {
  return ATTRIBUTE_LIST.reduce((sum, attribute) => sum + dieCost(character.attributes[attribute]), 0);
}

export function calculateTraitPoints(character) {
  const assetCost = character.traits.assets.reduce((sum, trait) => sum + dieCost(trait.rating), 0);
  const complicationGain = character.traits.complications.reduce((sum, trait) => sum + dieCost(trait.rating), 0);
  return HEROIC_LEVEL.traitPoints + complicationGain - assetCost;
}

export function calculateSkillPoints(character) {
  let total = 0;
  Object.values(character.skills).forEach((skill) => {
    total += dieCost(skill.generalRating || 'none');
    (skill.specialties || []).forEach((specialty) => {
      total += dieCost(specialty.rating || 'none');
    });
  });
  return total;
}

export function lifePoints(character) {
  return dieCost(character.attributes.Vitality) + dieCost(character.attributes.Willpower);
}

export function initiative(character) {
  return `${character.attributes.Agility} + ${character.attributes.Alertness}`;
}

export function remainingBudgets(character) {
  return {
    attributes: HEROIC_LEVEL.attributePoints - calculateAttributePoints(character),
    traits: calculateTraitPoints(character),
    skills: HEROIC_LEVEL.skillPoints - calculateSkillPoints(character)
  };
}

export function validateCharacter(character) {
  const errors = [];
  const budgets = remainingBudgets(character);

  if (budgets.attributes !== 0) {
    errors.push(`Attribute Points must spend exactly ${HEROIC_LEVEL.attributePoints}. Current remainder: ${budgets.attributes}.`);
  }

  if (budgets.skills < 0) {
    errors.push(`Skill Points overspent by ${Math.abs(budgets.skills)}.`);
  }

  if (budgets.traits < 0) {
    errors.push(`Trait Points overspent by ${Math.abs(budgets.traits)}.`);
  }

  const assetCount = character.traits.assets.filter((trait) => trait.name && trait.rating !== 'none').length;
  const complicationCount = character.traits.complications.filter((trait) => trait.name && trait.rating !== 'none').length;

  if (assetCount < 1) {
    errors.push('At least one Asset is required.');
  }
  if (complicationCount < 1) {
    errors.push('At least one Complication is required.');
  }

  Object.entries(character.skills).forEach(([skillName, skill]) => {
    const specialties = (skill.specialties || []).filter((item) => item.rating !== 'none');
    if (specialties.length > 0 && skill.generalRating !== 'd6') {
      errors.push(`${skillName} needs a General rating of d6 before specialties can count.`);
    }
    specialties.forEach((specialty) => {
      if (!specialty.name.trim()) {
        errors.push(`${skillName} has a specialty with a die rating but no name.`);
      }
    });
  });

  if (!character.basics.name.trim()) {
    errors.push('Character name is blank.');
  }
  if (!character.basics.concept.trim()) {
    errors.push('Character concept is blank.');
  }

  return {
    valid: errors.length === 0,
    errors,
    budgets,
    lifePoints: lifePoints(character),
    initiative: initiative(character)
  };
}
