import { ATTRIBUTE_LIST } from '../data/defaults.js';
import { calculateCurrentCredits, formatMoney, getGearPackageById } from '../data/gear_packages.js';
import { resolveRoleLabel } from '../data/roles.js';
import { effectiveGeneralRating, isAssignedAttributeDie } from '../rules.js';
import { el, sectionHeader } from '../ui.js';

let damageDrawerOpen = false;

function renderMoneyBlock(details) {
  return el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Money' }),
    el('p', { html: `<strong>Starting Credits:</strong> ${formatMoney(details.startingCredits, '₡')}` }),
    el('p', { html: `<strong>Current Credits:</strong> ${formatMoney(calculateCurrentCredits(details), '₡')}` }),
    el('p', { html: `<strong>Platinum Pieces:</strong> ${formatMoney(details.platinum, 'p')}` }),
    el('p', { html: `<strong>Money Notes:</strong> ${details.moneyNotes || '—'}` })
  ]);
}

function renderStarterPackageBlock(details) {
  const pkg = getGearPackageById(details.starterPackageId || '');
  if (!pkg) {
    return el('div', { cls: 'sheet-block' }, [
      el('h3', { text: 'Starter Package' }),
      el('p', { text: '—' })
    ]);
  }

  return el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Starter Package' }),
    el('p', { html: `<strong>${pkg.label}</strong>` }),
    el('p', { html: `<strong>Total Cost:</strong> ${formatMoney(pkg.costCredits, '₡')} / ${formatMoney(pkg.costPlatinum, 'p')}` }),
    el('p', { text: pkg.summary }),
    el('ul', { cls: 'summary-list' }, pkg.items.map((entry) => el('li', { html: `<strong>${entry.name}</strong> — ${formatMoney(entry.credits, '₡')} / ${formatMoney(entry.platinum, 'p')}` }))),
    el('p', { html: `<strong>Package Tweaks:</strong> ${details.starterPackageNotes || '—'}` })
  ]);
}

function renderTraits(list) {
  const filtered = list.filter((item) => item.name && item.rating !== 'none');
  if (!filtered.length) return el('p', { cls: 'muted', text: 'None selected.' });
  return el('ul', { cls: 'summary-list' }, filtered.map((trait) =>
    el('li', { text: `${trait.name} ${trait.rating}${trait.notes ? ` — ${trait.notes}` : ''}` })
  ));
}

function renderSkills(character) {
  const table = el('table', { cls: 'skill-table' });
  const thead = el('thead');
  thead.append(el('tr', {}, [
    el('th', { text: 'Skill' }),
    el('th', { text: 'General' }),
    el('th', { text: 'Specialties' })
  ]));
  const tbody = el('tbody');

  Object.entries(character.skills).forEach(([skillName, skill]) => {
    const specs = (skill.specialties || []).filter((item) => item.rating !== 'none' && item.name.trim()).map((item) => `${item.name} ${item.rating}`).join(', ');
    const effectiveGeneral = effectiveGeneralRating(character, skillName);
    if (effectiveGeneral === 'none' && !specs) return;
    tbody.append(el('tr', {}, [
      el('td', { text: skillName }),
      el('td', { text: effectiveGeneral }),
      el('td', { text: specs || '—' })
    ]));
  });

  table.append(thead, tbody);
  return table;
}

function buildAttributeRollRows(character) {
  const a = character.attributes;
  const pairDice = (left, right) => (
    isAssignedAttributeDie(left) && isAssignedAttributeDie(right) ? `${left} + ${right}` : '-'
  );
  return [
    { name: 'Burst of Strength', dice: pairDice(a.Strength, a.Strength), use: 'Brief feats of raw force, like shoving something heavy aside.' },
    { name: 'Endurance', dice: pairDice(a.Vitality, a.Willpower), use: 'Stay alive when your Wounds go past your Life Points.' },
    { name: 'Get Out of Harm’s Way', dice: pairDice(a.Agility, a.Alertness), use: 'React to sudden danger, dive clear, or move before something gets worse.' },
    { name: 'Long Haul', dice: pairDice(a.Strength, a.Vitality), use: 'Keep doing hard physical work over time, such as carrying a load uphill.' },
    { name: 'Memorize', dice: pairDice(a.Intelligence, a.Alertness), use: 'Commit important details to memory.' },
    { name: 'Recall', dice: pairDice(a.Intelligence, a.Willpower), use: 'Pull back an important fact or memory under pressure.' },
    { name: 'Resistance', dice: pairDice(a.Vitality, a.Vitality), use: 'Resist disease, toxins, hazards, drink, and other bodily misery.' }
  ];
}

function renderDerivedRolls(state) {
  const rows = [
    { label: 'Life Points', value: String(state.computed.lifePoints) },
    { label: 'Initiative', value: state.computed.initiative },
    ...buildAttributeRollRows(state.character).map((row) => ({ label: row.name, value: row.dice }))
  ];

  return el('div', { cls: 'derived-roll-list' }, rows.map((row) =>
    el('div', { cls: 'derived-roll-row' }, [
      el('span', { cls: 'derived-roll-label', text: row.label }),
      el('strong', { cls: 'derived-roll-value', text: row.value })
    ])
  ));
}

function clampDamage(value, max) {
  const parsed = Number.parseInt(value, 10);
  if (Number.isNaN(parsed)) return 0;
  return Math.max(0, Math.min(max, parsed));
}

function setDamageValue(mutateCharacter, key, nextValue, max) {
  mutateCharacter((draft) => {
    draft.trackers[key] = clampDamage(nextValue, max);
  });
}

function createDamageBubble(kind, bubbleValue, filled, mutateCharacter, current, max) {
  const button = el('button', {
    cls: `damage-bubble ${kind}${filled ? ' filled' : ''}`,
    attrs: {
      type: 'button',
      title: `${kind === 'stun' ? 'Stun' : 'Wounds'} ${bubbleValue}`,
      'aria-label': `${kind === 'stun' ? 'Set Stun to' : 'Set Wounds to'} ${bubbleValue}`
    }
  });

  button.addEventListener('click', () => {
    const nextValue = current === bubbleValue ? bubbleValue - 1 : bubbleValue;
    setDamageValue(mutateCharacter, kind, nextValue, max);
  });

  return button;
}

function renderDamageBubbleTrack(label, kind, value, max, mutateCharacter) {
  const block = el('div', { cls: `damage-bubble-track ${kind}` });
  const header = el('div', { cls: 'damage-bubble-track-head' }, [
    el('strong', { text: label }),
    el('span', { cls: 'muted', text: `${value} / ${max}` }),
    el('small', { cls: 'muted', text: kind === 'stun' ? 'Top ↓' : '↑ Bottom' })
  ]);

  const clear = el('button', {
    cls: 'damage-clear-button',
    text: 'Clear',
    attrs: { type: 'button', 'aria-label': `Clear ${label}` }
  });
  clear.addEventListener('click', () => setDamageValue(mutateCharacter, kind, 0, max));
  header.append(clear);

  const column = el('div', { cls: 'damage-bubble-column' });
  for (let visualIndex = 1; visualIndex <= max; visualIndex += 1) {
    const bubbleValue = kind === 'stun' ? visualIndex : (max - visualIndex + 1);
    const filled = kind === 'stun' ? visualIndex <= value : visualIndex > max - value;
    const row = el('div', { cls: 'damage-bubble-row' }, [
      createDamageBubble(kind, bubbleValue, filled, mutateCharacter, value, max),
      el('span', { cls: 'damage-bubble-count muted', text: String(bubbleValue) })
    ]);
    column.append(row);
  }

  block.append(header, column);
  return block;
}

function renderDamageDrawer(state, mutateCharacter) {
  const max = Math.max(1, state.computed.lifePoints);
  const stun = clampDamage(state.character.trackers?.stun ?? 0, max);
  const wounds = clampDamage(state.character.trackers?.wounds ?? 0, max);
  const total = stun + wounds;
  const outCold = total >= max;

  const drawer = el('aside', { cls: `damage-drawer no-print${damageDrawerOpen ? ' open' : ''}` });
  const tab = el('button', {
    cls: 'damage-drawer-tab',
    text: 'Damage',
    attrs: {
      type: 'button',
      'aria-expanded': damageDrawerOpen ? 'true' : 'false',
      'aria-label': damageDrawerOpen ? 'Hide damage tracker' : 'Show damage tracker'
    }
  });

  tab.addEventListener('click', () => {
    damageDrawerOpen = !damageDrawerOpen;
    drawer.classList.toggle('open', damageDrawerOpen);
    tab.setAttribute('aria-expanded', damageDrawerOpen ? 'true' : 'false');
    tab.setAttribute('aria-label', damageDrawerOpen ? 'Hide damage tracker' : 'Show damage tracker');
  });

  const panel = el('div', { cls: 'damage-drawer-panel' }, [
    el('div', { cls: 'damage-drawer-head' }, [
      el('h3', { text: 'Stun / Wounds' }),
      el('p', { cls: 'muted', text: 'Stun fills from the top. Wounds fill from the bottom. When they meet, the character is out.' })
    ]),
    el('div', { cls: `damage-state${outCold ? ' danger' : ''}` }, [
      el('span', { text: 'Current Total' }),
      el('strong', { text: `${total} / ${max}` }),
      el('small', { text: outCold ? 'Out cold or worse.' : 'Still upright.' })
    ]),
    el('div', { cls: 'damage-track-stack' }, [
      renderDamageBubbleTrack('Stun', 'stun', stun, max, mutateCharacter),
      renderDamageBubbleTrack('Wounds', 'wounds', wounds, max, mutateCharacter)
    ])
  ]);

  drawer.append(tab, panel);
  return drawer;
}

export function renderSheetStep(state, mutateCharacter) {
  const root = el('div');
  root.append(sectionHeader('Step 9: Character Sheet', 'This is the finished digital sheet. Keep it open, print it, or hand it to the player and let the Verse do its worst.'));

  const validation = el('div', { cls: `validation-box${state.computed.valid ? ' ok' : ''}` });
  validation.append(el('h3', { text: state.computed.valid ? 'Build looks legal.' : 'Build needs fixing.' }));
  if (state.computed.valid) {
    validation.append(el('p', { text: 'Points, required Traits, role training, and basic Greenhorn checks all pass.' }));
  } else {
    validation.append(el('ul', { cls: 'summary-list' }, state.computed.errors.map((error) => el('li', { text: error }))));
  }
  root.append(validation);

  const stage = el('div', { cls: 'sheet-stage' });
  const sheet = el('div', { cls: 'sheet-layout', attrs: { id: 'printableSheet' } });
  sheet.append(el('div', { cls: 'sheet-header' }, [
    el('div', {}, [
      el('h2', { text: state.character.basics.name || 'Unnamed Greenhorn' }),
      el('p', { text: state.character.basics.concept || 'No concept entered.' })
    ]),
    el('div', { cls: 'sheet-block' }, [
      el('div', { html: `<strong>Role:</strong> ${resolveRoleLabel(state.character.basics)}` }),
      el('div', { html: `<strong>Role Skill:</strong> ${state.character.basics.roleSkill || '—'}` }),
      el('div', { cls: 'muted', text: state.character.basics.roleSkill ? 'Free +d2 already baked into this core skill during creation.' : '' }),
      el('div', { html: `<strong>Homeworld:</strong> ${state.character.basics.homeworld || '—'}` }),
      el('div', { html: `<strong>Heroic Level:</strong> ${state.character.meta.heroicLevel}` })
    ])
  ]));

  sheet.append(el('div', { cls: 'sheet-info-grid' }, [
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Life Points' }), el('strong', { text: String(state.computed.lifePoints) })]),
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Initiative' }), el('strong', { text: state.computed.initiative })]),
    el('div', { cls: 'sheet-stat' }, [el('span', { text: 'Point Budgets' }), el('strong', { text: `A ${state.computed.budgets.attributes} | T ${state.computed.budgets.traits} | S ${state.computed.budgets.skills}` })])
  ]));

  sheet.append(el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Crew Hooks' }),
    el('p', { html: `<strong>Why the crew keeps them:</strong> ${state.character.basics.crewValue || '—'}` }),
    el('p', { html: `<strong>Connection:</strong> ${state.character.basics.crewConnection || '—'}` }),
    el('p', { html: `<strong>What they want from this crew:</strong> ${state.character.basics.crewMotivation || '—'}` })
  ]));

  sheet.append(el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Attributes' }),
    el('div', { cls: 'sheet-attr-grid' }, ATTRIBUTE_LIST.map((attribute) =>
      el('div', { cls: 'sheet-stat' }, [el('span', { text: attribute }), el('strong', { text: state.character.attributes[attribute] })])
    ))
  ]));

  sheet.append(el('div', { cls: 'grid-2' }, [
    el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Assets' }), renderTraits(state.character.traits.assets)]),
    el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Complications' }), renderTraits(state.character.traits.complications)])
  ]));

  sheet.append(el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Skills & Specialties' }), renderSkills(state.character)]));
  sheet.append(el('div', { cls: 'sheet-block' }, [el('h3', { text: 'Derived Rolls' }), renderDerivedRolls(state)]));
  sheet.append(renderMoneyBlock(state.character.details));
  sheet.append(renderStarterPackageBlock(state.character.details));
  sheet.append(el('div', { cls: 'sheet-block' }, [
    el('h3', { text: 'Gear & Notes' }),
    el('p', { html: `<strong>Additional Gear:</strong> ${state.character.details.gear || '—'}` }),
    el('p', { html: `<strong>Extra Notes:</strong> ${state.character.details.notes || '—'}` })
  ]));

  stage.append(sheet, renderDamageDrawer(state, mutateCharacter));
  root.append(stage);
  return root;
}
