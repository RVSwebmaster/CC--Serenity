import { calculateCurrentCredits, formatMoney, getGearPackageById } from '../data/gear_packages.js';
import { resolveRoleLabel } from '../data/roles.js';
import { effectiveGeneralRating } from '../rules.js';
import { el, sectionHeader } from '../ui.js';

function summarizeTopSkills(character) {
  const entries = Object.entries(character.skills)
    .map(([name]) => ({ name, rating: effectiveGeneralRating(character, name) }))
    .filter((item) => item.rating !== 'none')
    .sort((a, b) => ['none','d2','d4','d6'].indexOf(b.rating) - ['none','d2','d4','d6'].indexOf(a.rating));

  if (!entries.length) return el('p', { cls: 'muted', text: 'No skills bought yet.' });
  return el('ul', { cls: 'summary-list' }, entries.slice(0, 6).map((item) => el('li', { text: `${item.name} ${item.rating}` })));
}

function summarizePackage(character) {
  const pkg = getGearPackageById(character.details.starterPackageId || '');
  if (!pkg) return el('p', { text: 'No starter package selected.' });
  return el('div', {}, [
    el('p', { html: `<strong>${pkg.label}</strong> — ${formatMoney(pkg.costCredits, '₡')} / ${formatMoney(pkg.costPlatinum, 'p')}` }),
    el('p', { text: pkg.summary })
  ]);
}

export function renderReviewStep(state) {
  const root = el('div');
  root.append(sectionHeader('Step 8: Review', 'Look over the character as a whole before you generate the finished sheet. This is where you catch holes in the story as well as holes in the math.'));

  root.append(el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: 'Questions worth asking' }),
    el('ul', { cls: 'summary-list' }, [
      el('li', { text: 'Does this person actually fit the role they claim aboard ship?' }),
      el('li', { text: 'Do the Assets and Complications feel like the same person?' }),
      el('li', { text: 'Would you know how to play them in the first five minutes of a session?' })
    ])
  ]));

  const grid = el('div', { cls: 'grid-2' });
  grid.append(
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Identity' }),
      el('p', { html: `<strong>Name:</strong> ${state.character.basics.name || '—'}` }),
      el('p', { html: `<strong>Concept:</strong> ${state.character.basics.concept || '—'}` }),
      el('p', { html: `<strong>Role:</strong> ${resolveRoleLabel(state.character.basics)}` }),
      el('p', { html: `<strong>Role Skill:</strong> ${state.character.basics.roleSkill || '—'}` }),
      el('p', { html: `<strong>Homeworld:</strong> ${state.character.basics.homeworld || '—'}` })
    ]),
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Crew Hooks' }),
      el('p', { html: `<strong>Why the crew keeps them:</strong> ${state.character.basics.crewValue || '—'}` }),
      el('p', { html: `<strong>Connection:</strong> ${state.character.basics.crewConnection || '—'}` }),
      el('p', { html: `<strong>What they want:</strong> ${state.character.basics.crewMotivation || '—'}` })
    ]),
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Top Skills' }),
      summarizeTopSkills(state.character)
    ]),
    el('div', { cls: 'summary-card' }, [
      el('h3', { text: 'Finishing Touches' }),
      el('p', { html: `<strong>Starting Credits:</strong> ${formatMoney(state.character.details.startingCredits, '₡')}` }),
      el('p', { html: `<strong>Current Credits:</strong> ${formatMoney(calculateCurrentCredits(state.character.details), '₡')}` }),
      summarizePackage(state.character),
      el('p', { html: `<strong>Additional Gear Notes:</strong> ${state.character.details.gear || '—'}` })
    ]),
    el('div', { cls: `validation-box${state.computed.valid ? ' ok' : ''}` }, [
      el('h3', { text: state.computed.valid ? 'Build looks legal.' : 'Build still needs fixing.' }),
      state.computed.valid
        ? el('p', { text: 'If the story feels right too, hit Generate Sheet.' })
        : el('ul', { cls: 'summary-list' }, state.computed.errors.map((error) => el('li', { text: error })))
    ])
  );

  root.append(grid);
  return root;
}
