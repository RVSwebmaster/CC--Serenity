import { calculateCurrentCredits, formatMoney, getDefaultGearPackageId, getGearPackageById, GEAR_PACKAGES } from '../data/gear_packages.js';
import { el, field, sectionHeader } from '../ui.js';

function renderPackageCard(selectedPackage, selectedId) {
  if (!selectedPackage) {
    return el('div', { cls: 'summary-card guide-card' }, [
      el('h3', { text: 'Starter Package Help' }),
      el('p', { text: 'These starter kits use published item prices from the Serenity books. Choose one to see exactly what is in it and what it costs.' })
    ]);
  }

  return el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: selectedId ? 'Selected Starter Package' : 'Recommended Starter Package' }),
    el('p', { text: selectedPackage.summary }),
    el('p', { html: `<strong>Total Cost:</strong> ${formatMoney(selectedPackage.costCredits, '₡')} / ${formatMoney(selectedPackage.costPlatinum, 'p')}` }),
    el('p', { cls: 'muted', text: selectedPackage.pricing }),
    el('ul', { cls: 'summary-list' }, selectedPackage.items.map((entry) =>
      el('li', { html: `<strong>${entry.name}</strong> — ${formatMoney(entry.credits, '₡')} / ${formatMoney(entry.platinum, 'p')}` })
    ))
  ]);
}

export function renderDetailsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 7: Finishing Touches', 'Money first, then a quick starting package. These bundles use published item prices from Serenity and Six-Shooters & Spaceships so the deductions are honest.'));

  root.append(el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: 'Money in the Verse' }),
    el('p', { text: 'Prices are usually listed in Alliance credits (₡). Out on the Rim, folk also deal in platinum pieces (p). There is still no single universal Greenhorn cash number, so the GM sets the starting total and the kit comes out of that purse.' }),
    el('p', { cls: 'muted', text: 'Current credits are auto-calculated from Starting Credits minus the selected starter package total.' })
  ]));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const portrait = document.createElement('input');
  portrait.value = state.character.details.portraitUrl || '';
  portrait.placeholder = 'https://...';
  portrait.addEventListener('input', (event) => onChange((draft) => { draft.details.portraitUrl = event.target.value; }));
  left.append(field('Portrait URL (optional)', portrait, 'No upload system in the MVP. A simple image link works.'));

  const startingCredits = document.createElement('input');
  startingCredits.type = 'number';
  startingCredits.min = '0';
  startingCredits.step = '0.1';
  startingCredits.value = state.character.details.startingCredits || '';
  startingCredits.placeholder = '300';
  startingCredits.addEventListener('input', (event) => onChange((draft) => {
    draft.details.startingCredits = event.target.value;
    draft.details.currentCredits = String(calculateCurrentCredits(draft.details));
  }));
  left.append(field('Starting Credits (₡)', startingCredits, 'GM-set campaign baseline or your house-rule starting total.'));

  const currentCredits = document.createElement('input');
  currentCredits.type = 'number';
  currentCredits.min = '0';
  currentCredits.step = '0.1';
  currentCredits.value = String(calculateCurrentCredits(state.character.details));
  currentCredits.placeholder = 'Current ₡ on hand';
  currentCredits.readOnly = true;
  left.append(field('Current Credits (₡)', currentCredits, 'Auto-calculated as Starting Credits minus the selected starter package cost.'));

  const platinum = document.createElement('input');
  platinum.type = 'number';
  platinum.min = '0';
  platinum.step = '0.1';
  platinum.value = state.character.details.platinum || '';
  platinum.placeholder = 'Optional Rim coin';
  platinum.addEventListener('input', (event) => onChange((draft) => { draft.details.platinum = event.target.value; }));
  right.append(field('Platinum Pieces (p)', platinum, 'Optional. Useful for Rim cash, tips, and ugly little side deals.'));

  const moneyNotes = document.createElement('textarea');
  moneyNotes.value = state.character.details.moneyNotes || '';
  moneyNotes.placeholder = 'Company scrip, debt, wages due, hidden stash, or similar.';
  moneyNotes.addEventListener('input', (event) => onChange((draft) => { draft.details.moneyNotes = event.target.value; }));
  right.append(field('Money Notes', moneyNotes, 'Debt, wages, payroll share, hush money, church donation, whatever applies.'));

  const recommendedPackageId = getDefaultGearPackageId(state.character.basics.role);
  const recommendedPackage = getGearPackageById(recommendedPackageId);

  const packageSelect = document.createElement('select');
  const blankOption = document.createElement('option');
  blankOption.value = '';
  blankOption.textContent = 'Choose a starter package';
  packageSelect.append(blankOption);
  GEAR_PACKAGES.forEach((pkg) => {
    const option = document.createElement('option');
    option.value = pkg.id;
    option.textContent = pkg.label;
    if (pkg.id === (state.character.details.starterPackageId || '')) option.selected = true;
    packageSelect.append(option);
  });
  packageSelect.addEventListener('change', (event) => onChange((draft) => {
    draft.details.starterPackageId = event.target.value;
    draft.details.currentCredits = String(calculateCurrentCredits(draft.details));
  }));
  left.append(field('Starter Gear Package', packageSelect, recommendedPackage ? `Recommended for ${state.character.basics.role || 'this role'}: ${recommendedPackage.label}.` : 'Choose one of the book-priced starter kits or leave it blank.'));

  const packageNotes = document.createElement('textarea');
  packageNotes.value = state.character.details.starterPackageNotes || '';
  packageNotes.placeholder = 'Swapped pistol for something else, borrowed a tool, added crew-issued gear, and so on.';
  packageNotes.addEventListener('input', (event) => onChange((draft) => { draft.details.starterPackageNotes = event.target.value; }));
  left.append(field('Package Tweaks', packageNotes, 'Use this for swaps, additions, or anything your GM signed off on.'));

  const selectedPackage = getGearPackageById(state.character.details.starterPackageId || '') || recommendedPackage;
  right.append(renderPackageCard(selectedPackage, state.character.details.starterPackageId || ''));

  const gear = document.createElement('textarea');
  gear.value = state.character.details.gear || '';
  gear.addEventListener('input', (event) => onChange((draft) => { draft.details.gear = event.target.value; }));
  left.append(field('Additional Personal Gear', gear, 'Anything not covered by the starter package, including crew-issued odds and ends.'));

  const notes = document.createElement('textarea');
  notes.value = state.character.details.notes || '';
  notes.addEventListener('input', (event) => onChange((draft) => { draft.details.notes = event.target.value; }));
  right.append(field('Extra Notes', notes, 'Hooks for the GM, personal reminders, ship duty, debts, enemies.'));

  grid.append(left, right);
  root.append(grid);
  return root;
}
