const BOOK = 'Published item prices';

function item(name, credits, platinum, source = BOOK, notes = '') {
  return { name, credits, platinum, source, notes };
}

function total(items, key) {
  return Number(items.reduce((sum, entry) => sum + (Number(entry[key]) || 0), 0).toFixed(1));
}

function withTotals(pkg) {
  return {
    ...pkg,
    costCredits: total(pkg.items, 'credits'),
    costPlatinum: total(pkg.items, 'platinum')
  };
}

export const GEAR_PACKAGES = [
  withTotals({
    id: 'pilots-kit',
    label: 'Pilot’s Kit',
    roles: ['Pilot'],
    pricing: 'Official item prices',
    summary: 'A practical pilot loadout built from published gear, light enough for a cockpit and useful the minute the landing starts going sideways.',
    items: [
      item('Pistol', 18, 45, 'Core book, Table 3-9'),
      item('Ocular', 6, 15, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Ship-linked Handset', 3.2, 8, 'Core book, Table 3-13'),
      item('Glowstick', 2, 5, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Multi-Tool', 2, 5, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Filtration Canteen', 1.2, 3, 'Six-Shooters & Spaceships, Table 1.3')
    ]
  }),
  withTotals({
    id: 'mechanics-roll',
    label: 'Mechanic’s Roll',
    roles: ['Mechanic / Engineer'],
    pricing: 'Official item prices',
    summary: 'A stripped-down repair kit with enough real tools to patch, pry, cut, and improvise without pretending a full machine shop lives in your duffel.',
    items: [
      item('Tool Kit, Basic', 14.4, 36, 'Core book, Table 3-16'),
      item('Fusion Torch', 2.2, 6, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Multi-Tool', 2, 5, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Glowstick', 2, 5, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Burn Gel', 1.8, 5, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Patch Tape', 1.2, 3, 'Core book, Table 3-5')
    ]
  }),
  withTotals({
    id: 'medics-bag',
    label: 'Medic’s Bag',
    roles: ['Medic'],
    pricing: 'Official item prices',
    summary: 'A field-ready medical loadout with an honest doctor’s bag and enough basics to keep somebody breathing until the boat or the town can do better.',
    items: [
      item('Doctor’s Bag', 27.4, 69, 'Core book, Table 3-14'),
      item('Gas Mask', 4, 10, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Glowstick', 2, 5, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Burn Gel', 1.8, 5, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Filtration Canteen', 1.2, 3, 'Six-Shooters & Spaceships, Table 1.3'),
      item('First-Aid Kit', 0.6, 2, 'Core book, Table 3-14')
    ]
  }),
  withTotals({
    id: 'public-relations-kit',
    label: 'Public Relations Kit',
    roles: ['Public Relations'],
    pricing: 'Official item prices',
    summary: 'A social-operator kit built for faces, lies, and discreet coordination. It is not cheap, because charm backed by tools rarely is.',
    items: [
      item('Disguise Kit', 65.6, 164, 'Core book, Table 3-15'),
      item('DataBook', 30, 75, 'Core book, Table 3-12'),
      item('Micro Transmitter', 8, 20, 'Core book, Table 3-13'),
      item('Ocular', 6, 15, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Ship-linked Handset', 3.2, 8, 'Core book, Table 3-13')
    ]
  }),
  withTotals({
    id: 'general-hand-kit',
    label: 'General Hand Kit',
    roles: ['Shuttle Hand / General Crew', 'Cargo / Business', 'Captain', 'Cook / Utility Hand', 'Passenger', 'Companion', 'Hired Specialist', 'Drifter / Hired Hand', 'Other'],
    pricing: 'Official item prices',
    summary: 'Cheap, honest, and useful. The sort of gear a working soul can carry without turning their pockets into a bank loan.',
    items: [
      item('Multi-Tool', 2, 5, 'Six-Shooters & Spaceships, Table 1.1'),
      item('Glowstick', 2, 5, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Rucksack', 2, 5, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Filtration Canteen', 1.2, 3, 'Six-Shooters & Spaceships, Table 1.3'),
      item('Patch Tape', 1.2, 3, 'Core book, Table 3-5'),
      item('Utility Knife', 0.8, 2, 'Core book, Table 3-8'),
      item('First-Aid Kit', 0.6, 2, 'Core book, Table 3-14')
    ]
  })
];

export function getGearPackageById(id) {
  return GEAR_PACKAGES.find((pkg) => pkg.id === id) || null;
}

export function getDefaultGearPackageId(role) {
  const match = GEAR_PACKAGES.find((pkg) => (pkg.roles || []).includes(role));
  return match?.id || '';
}

export function getStarterPackageCost(id) {
  return getGearPackageById(id)?.costCredits || 0;
}

export function calculateCurrentCredits(details = {}) {
  const starting = Number.parseFloat(details.startingCredits);
  if (Number.isNaN(starting)) return '';
  const packageCost = getStarterPackageCost(details.starterPackageId || '');
  return Math.max(0, Number((starting - packageCost).toFixed(1)));
}

export function formatMoney(value, suffix, fallback = '—') {
  if (value === undefined || value === null || String(value).trim() === '') return fallback;
  const num = Number.parseFloat(value);
  const display = Number.isNaN(num) ? String(value) : (Number.isInteger(num) ? String(num) : num.toFixed(1));
  return `${display} ${suffix}`;
}
