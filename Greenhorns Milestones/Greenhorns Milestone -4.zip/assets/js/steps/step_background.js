import { el, field, sectionHeader } from '../ui.js';

export function renderBackgroundStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 3: Background & Ties', 'Now decide where this person came from, what they want, and why they do not feel like a stranger squatting in the same file as everyone else.'));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const homeworld = document.createElement('input');
  homeworld.value = state.character.basics.homeworld || '';
  homeworld.addEventListener('input', (event) => onChange((draft) => { draft.basics.homeworld = event.target.value; }));
  left.append(field('Homeworld', homeworld, 'Where did they learn to live the way they live?'));

  const background = document.createElement('textarea');
  background.value = state.character.basics.background || '';
  background.addEventListener('input', (event) => onChange((draft) => { draft.basics.background = event.target.value; }));
  left.append(field('Background / Notes', background, 'Keep it short. Enough to know what sort of trouble they carry around.'));

  const crewConnection = document.createElement('input');
  crewConnection.value = state.character.basics.crewConnection || '';
  crewConnection.addEventListener('input', (event) => onChange((draft) => { draft.basics.crewConnection = event.target.value; }));
  right.append(field('Connection to the Crew', crewConnection, 'A debt, a favor, a shared history, a relative, a lie, a friend, a feud. Something.'));

  const crewMotivation = document.createElement('textarea');
  crewMotivation.value = state.character.basics.crewMotivation || '';
  crewMotivation.addEventListener('input', (event) => onChange((draft) => { draft.basics.crewMotivation = event.target.value; }));
  right.append(field('What They Want From This Crew', crewMotivation, 'Money, belonging, a ride out, a purpose, a hiding place, revenge, redemption, whatever keeps them here.'));

  root.append(el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: 'Why this page matters' }),
    el('p', { text: 'Crew games get stronger when characters arrive with hooks. These answers give the GM handles and give you reasons to stay aboard when the trouble starts costing blood.' })
  ]));

  grid.append(left, right);
  root.append(grid);
  return root;
}
