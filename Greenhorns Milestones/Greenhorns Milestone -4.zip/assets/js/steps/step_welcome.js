import { el, field, sectionHeader } from '../ui.js';

export function renderWelcomeStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 1: Welcome', 'Start with the human being before the numbers. A Greenhorn is new to this life or at least new to being tested by it.'));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const name = document.createElement('input');
  name.value = state.character.basics.name || '';
  name.addEventListener('input', (event) => onChange((draft) => { draft.basics.name = event.target.value; }));
  left.append(field('Name', name, 'What do people call them when the shooting starts?'));

  const quote = document.createElement('input');
  quote.value = state.character.basics.quote || '';
  quote.addEventListener('input', (event) => onChange((draft) => { draft.basics.quote = event.target.value; }));
  left.append(field('Quote', quote, 'One line that sounds like them. Not mandatory, but useful.'));

  const concept = document.createElement('input');
  concept.value = state.character.basics.concept || '';
  concept.addEventListener('input', (event) => onChange((draft) => { draft.basics.concept = event.target.value; }));
  left.append(field('Concept', concept, 'A one-line pitch like “washed-up gunhand with decent manners” or “earnest medic who lies badly.”'));

  right.append(el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: 'What this page is for' }),
    el('p', { text: 'This is the part where the character stops being a pile of dice and starts being somebody worth following into trouble.' }),
    el('p', { cls: 'muted', text: 'The quote and concept both show up on the finished sheet, so keep them sharp.' })
  ]));

  right.append(el('div', { cls: 'summary-card' }, [
    el('h3', { text: 'Greenhorn tone' }),
    el('p', { text: 'Greenhorns are not blank slates. They know some things, they want some things, and they are still one bad decision away from becoming a cautionary tale.' })
  ]));

  grid.append(left, right);
  root.append(grid);
  return root;
}
