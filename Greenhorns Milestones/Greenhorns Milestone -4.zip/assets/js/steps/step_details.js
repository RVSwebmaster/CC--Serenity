import { el, field, sectionHeader } from '../ui.js';

export function renderDetailsStep(state, onChange) {
  const root = el('div');
  root.append(sectionHeader('Step 7: Finishing Touches', 'This is the small stuff that makes a finished sheet feel lived in instead of merely legal. Keep it light and practical.'));

  root.append(el('div', { cls: 'summary-card guide-card' }, [
    el('h3', { text: 'What belongs here' }),
    el('p', { text: 'Gear that matters, a note on starting cash if you care to track it, and any reminders that help the player run the character without digging through a notebook.' })
  ]));

  const grid = el('div', { cls: 'grid-2' });
  const left = el('div', { cls: 'field-card' });
  const right = el('div', { cls: 'field-card' });

  const portrait = document.createElement('input');
  portrait.value = state.character.details.portraitUrl || '';
  portrait.placeholder = 'https://...';
  portrait.addEventListener('input', (event) => onChange((draft) => { draft.details.portraitUrl = event.target.value; }));
  left.append(field('Portrait URL (optional)', portrait, 'No upload system in the MVP. A simple image link works.'));

  const credits = document.createElement('input');
  credits.value = state.character.details.credits || '';
  credits.placeholder = 'Starting credits, if you are tracking them';
  credits.addEventListener('input', (event) => onChange((draft) => { draft.details.credits = event.target.value; }));
  left.append(field('Credits / Cash', credits, 'Optional. Useful if you want the final sheet to carry starting money.'));

  const gear = document.createElement('textarea');
  gear.value = state.character.details.gear || '';
  gear.addEventListener('input', (event) => onChange((draft) => { draft.details.gear = event.target.value; }));
  left.append(field('Gear', gear, 'Weapons, tools, med kit, coat, lucky trinket, whatever matters.'));

  const notes = document.createElement('textarea');
  notes.value = state.character.details.notes || '';
  notes.addEventListener('input', (event) => onChange((draft) => { draft.details.notes = event.target.value; }));
  right.append(field('Extra Notes', notes, 'Hooks for the GM, personal reminders, ship duty, debts, enemies.'));

  grid.append(left, right);
  root.append(grid);
  return root;
}
