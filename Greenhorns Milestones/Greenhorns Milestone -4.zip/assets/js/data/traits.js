
export const CURATED_ASSETS = [
  { name: 'Allure', allowedRatings: ['d2', 'd4'], summary: 'Adds an edge when charm and appeal genuinely matter.' },
  { name: 'Athlete', allowedRatings: ['d2', 'd4'], summary: 'A broad edge on physical action where training and body control shine.' },
  { name: 'Born Behind the Wheel', allowedRatings: ['d2', 'd4'], summary: 'A pilot or driver trait for when instinct and vehicle handling carry the day.' },
  { name: 'Friends in High Places', allowedRatings: ['d2', 'd4'], summary: 'Connections with officials, officers, or the well-heeled.' },
  { name: 'Friends in Low Places', allowedRatings: ['d2', 'd4'], summary: 'Underworld contacts, dockside rumor, and street-level help.' },
  { name: 'Good Name', allowedRatings: ['d2', 'd4'], summary: 'Your reputation opens doors with the right sort of folk.' },
  { name: 'Highly Educated', allowedRatings: ['d2', 'd4'], summary: 'Formal learning, advanced study, or specialist schooling.' },
  { name: 'Lightnin’ Reflexes', allowedRatings: ['d4'], summary: 'A serious edge when fractions of a second matter.' },
  { name: 'Mean Left Hook', allowedRatings: ['d2'], summary: 'A specific gift for hurting people up close.' },
  { name: 'Steady Calm', allowedRatings: ['d2', 'd4'], summary: 'Nerves hold when panic would wreck lesser souls.' },
  { name: 'Talented', allowedRatings: ['d2', 'd4'], summary: 'Pick one narrow area where you are notably better than most.' },
  { name: 'Things Go Smooth', allowedRatings: ['d2', 'd4'], summary: 'Luck or timing seems to favor you at odd moments.' },
  { name: 'Tough as Nails', allowedRatings: ['d2', 'd4'], summary: 'Hard to put down, harder to keep there.' },
  { name: 'Trustworthy Gut', allowedRatings: ['d2'], summary: 'A practiced instinct for reading danger, lies, or bad turns.' }
];

export const CURATED_COMPLICATIONS = [
  { name: 'Amorous', allowedRatings: ['d2'], summary: 'Romantic or physical temptation can turn your head at bad times.' },
  { name: 'Chip on the Shoulder', allowedRatings: ['d2', 'd4'], summary: 'You are quick to take offense and slower to let it go.' },
  { name: 'Combat Paralysis', allowedRatings: ['d2'], summary: 'Violence can lock you up when the room turns ugly.' },
  { name: 'Coward', allowedRatings: ['d2'], summary: 'You want to live, and fear pushes your choices.' },
  { name: 'Credo', allowedRatings: ['d2', 'd4'], summary: 'A code, belief, or promise that can cost you dearly.' },
  { name: 'Dead Broke', allowedRatings: ['d2'], summary: 'Money trouble dogs every plan.' },
  { name: 'Greedy', allowedRatings: ['d2', 'd4'], summary: 'You reach for profit even when it is the wrong move.' },
  { name: 'Hooked', allowedRatings: ['d2', 'd4'], summary: 'You depend on a substance, treatment, or fix.' },
  { name: 'Leaky Brainpan', allowedRatings: ['d4'], summary: 'Your grip on reality, memory, or reason is not reliable.' },
  { name: 'Loyal', allowedRatings: ['d2', 'd4'], summary: 'Your obligations to a person, family, cause, or crew can bind you hard.' },
  { name: 'Memorable', allowedRatings: ['d2'], summary: 'People notice you, and anonymity slips through your fingers.' },
  { name: 'Non-Fightin’ Type', allowedRatings: ['d2'], summary: 'You are not built for violence, and it shows.' },
  { name: 'Overconfident', allowedRatings: ['d2'], summary: 'You think you can handle more than you ought.' },
  { name: 'Prejudice', allowedRatings: ['d2', 'd4'], summary: 'Bias or hatred colors your judgment.' },
  { name: 'Straight Shooter', allowedRatings: ['d2', 'd4'], summary: 'You say things plain, even when tact would save blood.' },
  { name: 'Superstitious', allowedRatings: ['d2'], summary: 'Signs, omens, and ritual can steer your choices.' },
  { name: 'Traumatic Flashes', allowedRatings: ['d2', 'd4'], summary: 'The past can seize the present without warning.' },
  { name: 'Ugly as Sin', allowedRatings: ['d2'], summary: 'Looks can work against you before you say a word.' },
  { name: 'Weak Stomach', allowedRatings: ['d2'], summary: 'Blood, gore, or foul conditions hit you harder than most.' }
];
