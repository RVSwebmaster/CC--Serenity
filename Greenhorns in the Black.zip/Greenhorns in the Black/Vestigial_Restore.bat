@echo off
setlocal

REM Run this BAT from the project root folder:
REM Example: C:\Users\rvsaw\Desktop\Greenhorns in the Black

echo.
echo ==========================================
echo Restore held files for Greenhorns
echo ==========================================
echo.

if not exist "index.html" (
    echo ERROR: index.html not found in this folder.
    echo Run this BAT from the project root.
    pause
    exit /b 1
)

call :restore_if_exists "__hold__app.bundle.js" "app.bundle.js"
call :restore_if_exists "assets\js\steps\__hold__step_basics.js" "assets\js\steps\step_basics.js"
call :restore_if_exists "docs\__hold__screen_flow.md" "docs\screen_flow.md"
call :restore_if_exists "docs\__hold__build_notes.md" "docs\build_notes.md"
call :restore_if_exists "docs\__hold__data_model.md" "docs\data_model.md"
call :restore_if_exists "exports\samples\__hold__sample_greenhorn.json" "exports\samples\sample_greenhorn.json"

echo.
echo Restore pass complete.
echo.
pause
exit /b 0

:restore_if_exists
set "OLD=%~1"
set "NEW=%~2"

if exist "%OLD%" (
    if exist "%NEW%" (
        echo SKIP: "%NEW%" already exists
    ) else (
        ren "%OLD%" "%~nx2"
        if errorlevel 1 (
            echo FAIL: "%OLD%"
        ) else (
            echo RESTORED: "%OLD%"  ^>  "%NEW%"
        )
    )
) else (
    echo MISSING: "%OLD%"
)
exit /b 0
