@echo off
setlocal

REM Run this BAT from the project root folder:
REM Example: C:\Users\rvsaw\Desktop\Greenhorns in the Black

echo.
echo ==========================================
echo Vestigial rename probe for Greenhorns
echo ==========================================
echo.

if not exist "index.html" (
    echo ERROR: index.html not found in this folder.
    echo Run this BAT from the project root.
    pause
    exit /b 1
)

call :rename_if_exists "app.bundle.js" "__hold__app.bundle.js"
call :rename_if_exists "assets\js\steps\step_basics.js" "assets\js\steps\__hold__step_basics.js"
call :rename_if_exists "docs\screen_flow.md" "docs\__hold__screen_flow.md"
call :rename_if_exists "docs\build_notes.md" "docs\__hold__build_notes.md"
call :rename_if_exists "docs\data_model.md" "docs\__hold__data_model.md"
call :rename_if_exists "exports\samples\sample_greenhorn.json" "exports\samples\__hold__sample_greenhorn.json"

echo.
echo Done.
echo If the app still launches and behaves normally, those files were not tied into the live runtime path.
echo If anything breaks, run Vestigial_Restore.bat from this same folder.
echo.
pause
exit /b 0

:rename_if_exists
set "OLD=%~1"
set "NEW=%~2"

if exist "%OLD%" (
    if exist "%NEW%" (
        echo SKIP: "%NEW%" already exists
    ) else (
        ren "%OLD%" "%~nx2"
        if errorlevel 1 (
            echo FAIL: "%OLD%"
        ) else (
            echo RENAMED: "%OLD%"  ^>  "%NEW%"
        )
    )
) else (
    echo MISSING: "%OLD%"
)
exit /b 0
